-- MySQL dump 10.13  Distrib 5.1.35, for Win32 (ia32)
--
-- Host: localhost    Database: crawler
-- ------------------------------------------------------
-- Server version	5.1.35-community

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `wiprorecord`
--

DROP TABLE IF EXISTS `wiprorecord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wiprorecord` (
  `RecordId` int(10) NOT NULL AUTO_INCREMENT,
  `URL` text NOT NULL,
  PRIMARY KEY (`RecordId`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wiprorecord`
--

LOCK TABLES `wiprorecord` WRITE;
/*!40000 ALTER TABLE `wiprorecord` DISABLE KEYS */;
INSERT INTO `wiprorecord` VALUES (1,'https://www.wipro.com'),(2,'http://www.wipro.com'),(3,'http://www.wipro.com/about-wipro/'),(4,'http://www.wipro.com/newsroom/'),(5,'http://www.wipro.com/investors/'),(6,'http://careers.wipro.com/'),(7,'http://www.wipro.com/contact/'),(8,'http://www.wipro.com/industries/'),(9,'http://www.wipro.com/industries/consumer-goods/'),(10,'http://www.wipro.com/industries/energy/'),(11,'http://www.wipro.com/industries/retail/'),(12,'http://www.wipro.com/industries/utilities/'),(13,'http://www.wipro.com/services/'),(14,'http://www.wipro.com/services/cloud-services/'),(15,'http://www.wipro.com/services/managed-services/'),(16,'http://www.wipro.com/services/open-source/'),(17,'http://www.wipro.com/services/product-engineering/'),(18,'http://www.wipro.com/insights/'),(19,'http://www.wipro.com/insights/?page_id=28'),(20,'http://www.wipro.com/insights/?page_id=25'),(21,'http://www.wipro.com/insights/?page_id=23'),(22,'http://www.wipro.com/insights/?page_id=17'),(23,'http://www.wipro.com/newsroom/?post_type=pressrelease&p=10049'),(24,'http://www.wipro.com/newsroom/?post_type=pressrelease&p=10046');
/*!40000 ALTER TABLE `wiprorecord` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-09-14  8:42:49
